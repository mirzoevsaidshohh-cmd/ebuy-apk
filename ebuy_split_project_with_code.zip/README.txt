eBuy split project

Open index.html in a browser.
HTML structure: index.html
All design/CSS code: style.css
All JavaScript/app logic: script.js
Images folder: images/
